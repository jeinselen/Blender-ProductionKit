import bpy
import math
from bpy.app.handlers import persistent
from colorsys import hsv_to_rgb
from mathutils import noise

########## Easing Functions (adapted from the work of Robert Penner and https://easings.net/)

# LINEAR
def linear(t): return t

# Smoothstep and Smootherstep variations
def ease_in_smooth(t): return ease_in_out_smooth(t * 0.5) * 2.0
def ease_out_smooth(t): return ease_in_out_smooth(t * 0.5 + 0.5) * 2.0 - 1.0
def ease_in_out_smooth(t):
	return t * t * (3 - 2 * t)

def ease_in_smoothx(t): return ease_in_out_smoothx(t * 0.5) * 2.0
def ease_out_smoothx(t): return ease_in_out_smoothx(t * 0.5 + 0.5) * 2.0 - 1.0
def ease_in_out_smoothx(t):
	t = t * t * (3 - 2 * t)
	return t * t * (3 - 2 * t)

def ease_in_smoother(t): return ease_in_out_smoother(t * 0.5) * 2.0
def ease_out_smoother(t): return ease_in_out_smoother(t * 0.5 + 0.5) * 2.0 - 1.0
def ease_in_out_smoother(t):
	return t * t * t * (t * (6 * t - 15) + 10)

# SINE
def ease_in_sine(t): return 1 - math.cos((t * math.pi) / 2)
def ease_out_sine(t): return math.sin((t * math.pi) / 2)
def ease_in_out_sine(t): return -(math.cos(math.pi * t) - 1) / 2

# QUAD
def ease_in_quad(t): return t * t
def ease_out_quad(t): return 1 - (1 - t) * (1 - t)
def ease_in_out_quad(t):
	return 2 * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 2) / 2

# CUBIC
def ease_in_cubic(t): return t ** 3
def ease_out_cubic(t): return 1 - pow(1 - t, 3)
def ease_in_out_cubic(t):
	return 4 * t ** 3 if t < 0.5 else 1 - pow(-2 * t + 2, 3) / 2

# QUART
def ease_in_quart(t): return t ** 4
def ease_out_quart(t): return 1 - pow(1 - t, 4)
def ease_in_out_quart(t):
	return 8 * t ** 4 if t < 0.5 else 1 - pow(-2 * t + 2, 4) / 2

# QUINT
def ease_in_quint(t): return t ** 5
def ease_out_quint(t): return 1 - pow(1 - t, 5)
def ease_in_out_quint(t):
	return 16 * t ** 5 if t < 0.5 else 1 - pow(-2 * t + 2, 5) / 2

# EXPO
def ease_in_expo(t):
	return 0 if t == 0 else pow(2, 10 * t - 10)
def ease_out_expo(t):
	return 1 if t == 1 else 1 - pow(2, -10 * t)
def ease_in_out_expo(t):
	if t == 0: return 0
	if t == 1: return 1
	return pow(2, 20 * t - 10) / 2 if t < 0.5 else (2 - pow(2, -20 * t + 10)) / 2

# CIRC
def ease_in_circ(t): return 1 - math.sqrt(1 - t * t)
def ease_out_circ(t): return math.sqrt(1 - pow(t - 1, 2))
def ease_in_out_circ(t):
	return (1 - math.sqrt(1 - (2 * t) ** 2)) / 2 if t < 0.5 else (math.sqrt(1 - pow(-2 * t + 2, 2)) + 1) / 2

# BACK
c1 = 1.70158
c2 = c1 * 1.525
c3 = c1 + 1
def ease_in_back(t): return c3 * t * t * t - c1 * t * t
def ease_out_back(t): return 1 + c3 * pow(t - 1, 3) + c1 * pow(t - 1, 2)
def ease_in_out_back(t):
	if t < 0.5:
		return (pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2
	else:
		return (pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2
	
# ELASTIC
c4 = (2 * math.pi) / 3
c5 = (2 * math.pi) / 4.5
def ease_in_elastic(t):
	if t == 0 or t == 1: return t
	return -pow(2, 10 * t - 10) * math.sin((t * 10 - 10.75) * c4)
def ease_out_elastic(t):
	if t == 0 or t == 1: return t
	return pow(2, -10 * t) * math.sin((t * 10 - 0.75) * c4) + 1
def ease_in_out_elastic(t):
	if t == 0 or t == 1: return t
	if t < 0.5:
		return -(pow(2, 20 * t - 10) * math.sin((20 * t - 11.125) * c5)) / 2
	else:
		return (pow(2, -20 * t + 10) * math.sin((20 * t - 11.125) * c5)) / 2 + 1
	
# BOUNCE
def ease_out_bounce(t):
	n1, d1 = 7.5625, 2.75
	if t < 1 / d1:
		return n1 * t * t
	elif t < 2 / d1:
		t -= 1.5 / d1
		return n1 * t * t + 0.75
	elif t < 2.5 / d1:
		t -= 2.25 / d1
		return n1 * t * t + 0.9375
	else:
		t -= 2.625 / d1
		return n1 * t * t + 0.984375
def ease_in_bounce(t): return 1 - ease_out_bounce(1 - t)
def ease_in_out_bounce(t):
	return (1 - ease_out_bounce(1 - 2 * t)) / 2 if t < 0.5 else (1 + ease_out_bounce(2 * t - 1)) / 2

# Inverted functions (mirrored along x=y linear diagonal) for fast in/out instead of slow
# Only supports monotonic formulas, smootherstep skipped due to complexity

# Helper functions
def clamp01(x): return max(0.0, min(1.0, x))

# INV_SMOOTH
def inv_ease_in_out_smooth(x): return 0.5 - math.sin(math.asin(1.0 - 2.0 * x) / 3.0)
def inv_ease_in_smooth(x): return 2.0 * inv_ease_in_out_smooth(x * 0.5)
def inv_ease_out_smooth(x): return 2.0 * inv_ease_in_out_smooth((x + 1.0) * 0.5) - 1.0

# INV_SMOOTHX
def inv_ease_in_out_smoothx(x): return inv_ease_in_out_smooth(inv_ease_in_out_smooth(x))
def inv_ease_in_smoothx(x): return 2.0 * inv_ease_in_out_smoothx(x * 0.5)
def inv_ease_out_smoothx(x): return 2.0 * inv_ease_in_out_smoothx((x + 1.0) * 0.5) - 1.0

# INV_SINE
def inv_ease_in_sine(x): return (2.0 / math.pi) * math.acos(1.0 - x)
def inv_ease_out_sine(x): return (2.0 / math.pi) * math.asin(x)
def inv_ease_in_out_sine(x): return math.acos(1.0 - 2.0 * x) / math.pi

# INV_QUAD
def inv_ease_in_quad(x): return math.sqrt(x)
def inv_ease_out_quad(x): return 1.0 - math.sqrt(1.0 - x)
def inv_ease_in_out_quad(x): return math.sqrt(x * 0.5) if x < 0.5 else 1.0 - math.sqrt((1.0 - x) * 0.5)

# INV_CUBIC
def cbrt(x): return math.copysign(abs(x) ** (1.0 / 3.0), x)
def inv_ease_in_cubic(x): return cbrt(x)
def inv_ease_out_cubic(x): return 1.0 - cbrt(1.0 - x)
def inv_ease_in_out_cubic(x): return cbrt(x * 0.25) if x < 0.5 else 1.0 - cbrt((1.0 - x) * 0.25)

# INV_QUART
def inv_ease_in_quart(x): return x ** 0.25
def inv_ease_out_quart(x): return 1.0 - ((1.0 - x) ** 0.25)
def inv_ease_in_out_quart(x): return (x / 8.0) ** 0.25 if x < 0.5 else 1.0 - ((1.0 - x) / 8.0) ** 0.25

# INV_QUINT
def inv_ease_in_quint(x): return x ** 0.2
def inv_ease_out_quint(x): return 1.0 - ((1.0 - x) ** 0.2)
def inv_ease_in_out_quint(x): return (x / 16.0) ** 0.2 if x < 0.5 else 1.0 - ((1.0 - x) / 16.0) ** 0.2

# INV_EXPO
def inv_ease_in_expo(x): return 0.0 if x <= 0.0 else clamp01((math.log2(x) + 10.0) / 10.0)
def inv_ease_out_expo(x): return 1.0 if x >= 1.0 else clamp01(-math.log2(1.0 - x) / 10.0)
def inv_ease_in_out_expo(x):
	if x <= 0.0: return 0.0
	if x >= 1.0: return 1.0
	return clamp01((math.log2(2.0 * x) + 10.0) / 20.0) if x < 0.5 else clamp01((10.0 - math.log2(2.0 * (1.0 - x))) / 20.0)

# INV_CIRC
def inv_ease_in_circ(x): return math.sqrt(1.0 - (1.0 - x) * (1.0 - x))
def inv_ease_out_circ(x): return 1.0 - math.sqrt(1.0 - x * x)
def inv_ease_in_out_circ(x): return 0.5 * math.sqrt(1.0 - (1.0 - 2.0 * x) ** 2) if x < 0.5 else 1.0 - 0.5 * math.sqrt(1.0 - (2.0 * x - 1.0) ** 2)



# Library
easing_functions = {
	"linear": {
		"in": linear,
		"out": linear,
		"inout": linear
	},
	"smooth": {
		"in": ease_in_smooth,
		"out": ease_out_smooth,
		"inout": ease_in_out_smooth
	},
	"smoothx": {
		"in": ease_in_smoothx,
		"out": ease_out_smoothx,
		"inout": ease_in_out_smoothx
	},
	"smoother": {
		"in": ease_in_smoother,
		"out": ease_out_smoother,
		"inout": ease_in_out_smoother
	},
	"sine": {
		"in": ease_in_sine,
		"out": ease_out_sine,
		"inout": ease_in_out_sine
	},
	"quad": {
		"in": ease_in_quad,
		"out": ease_out_quad,
		"inout": ease_in_out_quad
	},
	"cubic": {
		"in": ease_in_cubic,
		"out": ease_out_cubic,
		"inout": ease_in_out_cubic
	},
	"quart": {
		"in": ease_in_quart,
		"out": ease_out_quart,
		"inout": ease_in_out_quart
	},
	"quint": {
		"in": ease_in_quint,
		"out": ease_out_quint,
		"inout": ease_in_out_quint
	},
	"expo": {
		"in": ease_in_expo,
		"out": ease_out_expo,
		"inout": ease_in_out_expo
	},
	"circ": {
		"in": ease_in_circ,
		"out": ease_out_circ,
		"inout": ease_in_out_circ
	},
	"back": {
		"in": ease_in_back,
		"out": ease_out_back,
		"inout": ease_in_out_back
	},
	"elastic": {
		"in": ease_in_elastic,
		"out": ease_out_elastic,
		"inout": ease_in_out_elastic
	},
	"bounce": {
		"in": ease_in_bounce,
		"out": ease_out_bounce,
		"inout": ease_in_out_bounce
	},
	"inv_smooth": {
		"in": inv_ease_in_smooth,
		"out": inv_ease_out_smooth,
		"inout": inv_ease_in_out_smooth
	},
	"inv_smoothx": {
		"in": inv_ease_in_smoothx,
		"out": inv_ease_out_smoothx,
		"inout": inv_ease_in_out_smoothx
	},
	"inv_sine": {
		"in": inv_ease_in_sine,
		"out": inv_ease_out_sine,
		"inout": inv_ease_in_out_sine
	},
	"inv_quad": {
		"in": inv_ease_in_quad,
		"out": inv_ease_out_quad,
		"inout": inv_ease_in_out_quad
	},
	"inv_cubic": {
		"in": inv_ease_in_cubic,
		"out": inv_ease_out_cubic,
		"inout": inv_ease_in_out_cubic
	},
	"inv_quart": {
		"in": inv_ease_in_quart,
		"out": inv_ease_out_quart,
		"inout": inv_ease_in_out_quart
	},
	"inv_quint": {
		"in": inv_ease_in_quint,
		"out": inv_ease_out_quint,
		"inout": inv_ease_in_out_quint
	},
	"inv_expo": {
		"in": inv_ease_in_expo,
		"out": inv_ease_out_expo,
		"inout": inv_ease_in_out_expo
	},
	"inv_circ": {
		"in": inv_ease_in_circ,
		"out": inv_ease_out_circ,
		"inout": inv_ease_in_out_circ
	}
}

# Easing function for accessing all of the above from a single line
def get_ease(time, ease_type, direction):
	try:
		func = easing_functions[ease_type.lower()][direction.lower()]
		return func(time)
	except KeyError:
		raise ValueError(f"Easing not found for type='{ease_type}' and direction='{direction}'")





########## Driver Functions

#	curveAtTime(item name, animation curve index, sample time in frames)
#	curveAtTime("Cube", 0, frame-5)
#	returns the "Cube" object's first animation curve value 5 frames in the past
#	Blender requires an animation curve to get non-current-frame data
#	Blender doesn't reference animation curves by type or name, only numerical index
def curve_at_time(name, channel, frame):
	obj = bpy.data.objects[name]
	fcurve = obj.animation_data.action.fcurves[channel]
	return fcurve.evaluate(frame)



#	ease(time, type, direction)
#	ease(frame/30, circular, inout)
#	Implements common easing functions for a value between 0 and 1
#	Expected use case is within additional math expressions to map the 0-1 range to the desired values
def ease(time, ease_type, direction, a=0, b=1):
	if time <= 0:
		return a
	elif time >= 1:
		return b
	else:
		if a == 0 and b == 1:
			return get_ease(time, ease_type, direction)
		else:
			return lerp(a, b, get_ease(time, ease_type, direction))



#	hash(string)
#	hash("string of text")
#	Returns value within the range 0 to 99999 based on the pseudo-hash of a string (deterministic based on sum ord)
def hash(string=0):
	if "{project}" in string:
		import os
		string = string.replace("{project}", os.path.splitext(os.path.basename(bpy.data.filepath))[0])
	if "{scene}" in string:
		string = string.replace("{scene}", bpy.context.scene.name)
	if "{viewlayer}" in string:
		string = string.replace("{viewlayer}", bpy.context.view_layer.name)
#	return int(sum(ord(c) for c in str(string)) * 123.456) % 99999
	return int(sum((i + 1) * ord(c) for i, c in enumerate(str(string))) % 99999)



#	hsv(hue, saturation, value, output channel)
#	hsv(0.5, 1, 1, 0)
#	This will convert HSV input values into RGB output values, returning the first (red) channel
def hsv(h, s, v, c):
	color = hsv_to_rgb(h, s, v)
	if c < 0.5:
		return color[0]
	elif c < 1.5:
		return color[1]
	else:
		return color[2]



#	lerp(value A, value B, value mix)
#	lerp(0.75, 0.25, 0.5)
#	This will mix between two values
def lerp(a, b, c):
	if c <= 0:
		return a
	elif c >= 1:
		return b
	else:
		return (a * (1 - c)) + (b * c)



#	markerValue(required: marker name, optional: static or relative time, frames or seconds, clamp, duration, start value, end value, ease type, ease directions)
#	markerValue('marker_1')
#	markerValue('marker_1', False, True)
#	markerValue('marker_1', True, True, True, 1.0)
#	markerValue('marker_1', True, True, True, 1.0, -0.5, 0.5, 'smooth', 'inout')
def marker_value(name, relative=False, seconds=False, clamp=False, duration=1, a=0, b=1, ease_type='linear', direction='inout'):
	scene = bpy.context.scene
	frame = 0
	if scene.timeline_markers.find(name) > -1:
		frame = scene.timeline_markers.get(name).frame
		if relative:
			frame = scene.frame_current - frame
		if seconds:
			frame /= scene.render.fps / scene.render.fps_base
			if clamp:
				frame = min(max(frame/duration, 0), 1)
				if ease_type != 'linear':
					frame = get_ease(frame, ease_type, direction)
			if a != 0 or b != 1:
				frame = (a * (1 - frame)) + (b * frame)
	return frame

#	markerPrev(optional: text filter, static or relative time, frames or seconds, clamp, duration, start value, end value, ease type, ease directions)
#	markerPrev('')
#	markerPrev('marker_')
#	markerPrev('marker_', False, True)
#	markerPrev('marker_', True, True, True, 1.0)
#	markerPrev('marker_', True, True, True, 1.0, -0.5, 0.5, 'smooth', 'inout')
def marker_prev(name=False, relative=False, seconds=False, clamp=False, duration=1, a=0, b=1, ease_type='linear', direction='inout'):
	scene = bpy.context.scene
	frame = scene.frame_start
	# Find closest marker frame at or before current frame
	if len(scene.timeline_markers) > 0:
		frame = -100000
		marker_found = False
		for marker in scene.timeline_markers:
			if (name and name in marker.name) or not name:
				marker_found = True
				if marker.frame <= scene.frame_current and marker.frame > frame:
					frame = marker.frame
		if not marker_found:
			frame = scene.frame_start
		if relative:
			frame = scene.frame_current - frame
		if seconds:
			frame /= scene.render.fps / scene.render.fps_base
			if clamp:
				frame = min(max(frame/duration, 0), 1)
				if ease_type != 'linear':
					frame = get_ease(frame, ease_type, direction)
			if a != 0 or b != 1:
				frame = (a * (1 - frame)) + (b * frame)
	return frame

#	markerNext(optional: text filter, static or relative time, frames or seconds, clamp, duration, start value, end value, ease type, ease directions)
#	markerNext()
#	markerNext('marker_')
#	markerNext('marker_', False, True)
#	markerNext('marker_', True, True, True, 1.0)
#	markerNext('marker_', True, True, True, 1.0, -0.5, 0.5, 'smooth', 'inout')
def marker_next(name=False, relative=False, seconds=False, clamp=False, duration=1, a=0, b=1, ease_type='linear', direction='inout'):
	scene = bpy.context.scene
	frame = scene.frame_end
	# Find closest marker frame at or before current frame
	if len(scene.timeline_markers) > 0:
		frame = 100000
		marker_found = False
		for marker in scene.timeline_markers:
			if (name and name in marker.name) or not name:
				marker_found = True
				if marker.frame >= scene.frame_current and marker.frame < frame:
					frame = scene.frame_current - marker.frame if relative else marker.frame
		if not marker_found:
			frame = scene.frame_end
		if relative:
			frame = scene.frame_current - frame
		if seconds:
			frame /= scene.render.fps / scene.render.fps_base
			if clamp:
				frame = min(max(frame/duration, 0), 1)
				if ease_type != 'linear':
					frame = get_ease(frame, ease_type, direction)
			if a != 0 or b != 1:
				frame = (a * (1 - frame)) + (b * frame)
	return frame

#	markerRange(required: marker start, marker end, optional: clamp, start value, end value, ease type, ease directions)
#	markerRange('marker_1', 'marker_2')
#	markerRange('marker_1', 'marker_2', False, -0.5, 0.5)
#	markerRange('marker_1', 'marker_2', True, -0.5, 0.5, 'smooth', 'inout')
def marker_range(start, end, clamp=False, a=0, b=1, ease_type='linear', direction='inout'):
	scene = bpy.context.scene
	if scene.timeline_markers.find(start) > -1 and scene.timeline_markers.find(end) > -1:
		start = scene.timeline_markers.get(start).frame
		end = scene.timeline_markers.get(end).frame
		if clamp and scene.frame_current <= start:
			return a
		elif clamp and scene.frame_current >= end:
			return b
		else:
			c = (scene.frame_current - start) / (end - start)
			if clamp:
				c = min(max(c, 0), 1)
				if ease_type != 'linear':
					c = get_ease(c, ease_type, direction)
			if a != 0 or b != 1:
				c = (a * (1.0 - c)) + (b * c)
			return c
	else:
		return 0.0



#	random(minimum, maximum, seed)
#	markerRangeClamp(0.5, 1.5, 3575)
def random(a, b, s=-1):
	if s >= 0:
		noise.seed_set(int(s))
	return (noise.random() * (b - a)) + a



#	wiggle(speed, distance, octaves, seed)
#	wiggle(2, 1, 3, 4)
#	This is vaguely comparable to AE's 2 wiggles per second moving a distance of 1m with 3 octaves and a random seed of 4
def wiggle(freq, amp, oct, seed):
	time = bpy.context.scene.frame_current / bpy.context.scene.render.fps
	pos = (time*0.73*freq, time*0.53*freq, seed) # magic numbers to try and mimic the actually-faster-than-per-second wiggle value in AE
	return noise.fractal(pos, 1.0, 2.0, oct, noise_basis='PERLIN_ORIGINAL') * amp





###########################################################################
# Action classes

class CopyDriverToClipboard(bpy.types.Operator):
	"""Copy the specified string to the clipboard"""
	bl_idname = "object.copy_to_clipboard"
	bl_label = "Copy Text"
	
	string: bpy.props.StringProperty(default="")
	
	def execute(self, context):
		context.window_manager.clipboard = self.string
		return {'FINISHED'}



class WM_OT_find_replace_marker_expression(bpy.types.Operator):
	"""Find and replace string in all marker names and driver expressions"""
	bl_idname = "wm.find_replace_marker_expression"
	bl_label = "Replace Marker Names & Driver Expressions"
	bl_options = {'REGISTER', 'UNDO'}
	
	def execute(self, context):
		settings = context.scene.production_kit_settings
		find = settings.driver_marker_find
		replace = settings.driver_marker_replace
		
		# Statistics
		markers_modified = 0
		drivers_modified = 0
		
		# Process all timeline markers
		if bpy.context.scene.timeline_markers:
			for marker in bpy.context.scene.timeline_markers:
				if find in marker.name:
					marker.name = marker.name.replace(find, replace)
					markers_modified += 1
					print(f"Modified marker: {marker.name}")
		
		# Process all objects and their drivers
		for obj in bpy.data.objects:
			# Check if object has animation data
			if obj.animation_data and obj.animation_data.drivers:
				for driver in obj.animation_data.drivers:
					# Check the driver's expression
					if driver.driver and driver.driver.expression:
						if find in driver.driver.expression:
							driver.driver.expression = driver.driver.expression.replace(
								find, replace
							)
							drivers_modified += 1
							print(f"Modified driver on {obj.name}: {driver.data_path}")
		
		# Also check other data types that can have drivers
		data_collections = [
			bpy.data.materials,
			bpy.data.node_groups,
			bpy.data.scenes,
			bpy.data.worlds,
			bpy.data.lights,
			bpy.data.cameras,
			bpy.data.meshes,
			bpy.data.curves,
			bpy.data.metaballs,
			bpy.data.lattices,
			bpy.data.armatures,
			bpy.data.speakers,
			bpy.data.textures,
		]
		
		for collection in data_collections:
			for data_item in collection:
				if data_item.animation_data and data_item.animation_data.drivers:
					for driver in data_item.animation_data.drivers:
						if driver.driver and driver.driver.expression:
							if find in driver.driver.expression:
								driver.driver.expression = driver.driver.expression.replace(
									find, replace
								)
								drivers_modified += 1
								print(f"Modified driver on {data_item.name}: {driver.data_path}")
		
		# Print summary
		print(f"\n--- Find & Replace Complete ---")
		print(f"Search string: '{find}'")
		print(f"Replace string: '{replace}'")
		print(f"Markers modified: {markers_modified}")
		print(f"Drivers modified: {drivers_modified}")
		print(  f"-------------------------------\n")
		
		return {'FINISHED'}





###########################################################################
# UI rendering classes

class PRODUCTIONKIT_PT_driverFunctions(bpy.types.Panel):
	bl_label = "Driver Functions"
	bl_idname = "PRODUCTIONKIT_PT_driverFunctions"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = 'Launch'
	bl_order = 24
	bl_options = {'DEFAULT_CLOSED'}
	
	@classmethod
	def poll(cls, context):
		return True # context.active_object
	
	def draw_header(self, context):
		try:
			layout = self.layout
		except Exception as exc:
			print(str(exc) + " | Error in Production Kit Driver Functions panel header")
	
	def draw(self, context):
		settings = context.scene.production_kit_settings
		try:
			layout = self.layout
			layout.use_property_decorate = False # No animation
			
			col = layout.column(align=True)
			col.prop(settings, 'driver_select', text='')
			
			# Driver string
			driver = ''
			
			# Error tracker
			error = ''
			
			# Curve At Time
			if settings.driver_select == 'CURVE':
				if context.active_object:
					obj = context.active_object
					if obj.animation_data and obj.animation_data.action and obj.animation_data.action.fcurves:
						col.prop(settings, 'driver_curve_channel')
						col.prop(settings, 'driver_curve_offset')
						
						driver = f"curveAtTime('{context.active_object.name}', {settings.driver_curve_channel}, {settings.driver_curve_offset})"
					else:
						error = 'no animation curves'
				else:
					error = 'no active object'
			
			# Ease
			if settings.driver_select == 'EASE':
				row1 = col.row(align=True)
				row1.prop(settings, 'driver_value_t', text='')
				row1.prop(settings, 'driver_ease_type', text='')
				row1.prop(settings, 'driver_ease_direction', text='')
				
				driver = f"ease({settings.driver_value_t}, '{settings.driver_ease_type}', '{settings.driver_ease_direction}')"
			
			# Hash
			if settings.driver_select == 'HASH':
				row1 = col.row(align=True)
				row1.prop(settings, 'driver_var_project', toggle=1)
				row1.prop(settings, 'driver_var_scene', toggle=1)
				row1.prop(settings, 'driver_var_viewlayer', toggle=1)
				
				driver = "hash('"
				if not (settings.driver_var_project or settings.driver_var_scene or settings.driver_var_viewlayer):
					driver += "string"
				else:
					if settings.driver_var_project:
						driver += "{project}"
					if settings.driver_var_scene:
						driver += "{scene}"
					if settings.driver_var_viewlayer:
						driver += "{viewlayer}"
				driver += "')"
			
			# Lerp
			if settings.driver_select == 'LERP':
				row1 = col.row(align=True)
				row1.prop(settings, 'driver_value_a')
				row1.prop(settings, 'driver_value_b')
				row1.prop(settings, 'driver_value_c')
				
				driver = f"lerp({settings.driver_value_a}, {settings.driver_value_b}, {settings.driver_value_c})"
			
			# Marker
			elif 'MARKER-' in settings.driver_select:
				if context.scene.timeline_markers:
					# Settings
					relative = True if settings.driver_marker_relative == 'RELATIVE' else False
					seconds = True if settings.driver_marker_seconds == 'SECONDS' else False
					clamp = True if settings.driver_marker_clamp == 'CLAMP' else False
					duration = settings.driver_marker_duration
					valueA = settings.driver_value_a
					valueB = settings.driver_value_b
					range = False
					
					# Marker Value
					if settings.driver_select == 'MARKER-VALUE':
						# Marker selection
						col.prop_search(settings, "driver_marker_name", context.scene, "timeline_markers", text="")
						col.separator()
						
						# Time settings
						row1 = col.row(align=True)
						row1.prop(settings, 'driver_marker_relative', expand=True)
						row2 = col.row(align=True)
						row2.prop(settings, 'driver_marker_seconds', expand=True)
						row3 = col.row(align=True)
						if not (relative and seconds):
							row3.active = False
							row3.enabled = False
							duration = 1
						row3.prop(settings, 'driver_marker_clamp', expand=True)
						
						if settings.driver_marker_name == '':
							error = 'missing marker name'
						else:
							# Short version for basic usage (interpolation added below)
							driver = f"markerValue('{settings.driver_marker_name}'"
					
					# Marker Next and Marker Previous
					elif settings.driver_select in ['MARKER-PREV', 'MARKER-NEXT']:
						# Marker selection
						row1 = col.row(align=True)
						row1.prop(settings, 'driver_marker_filter', expand=True)
						option = col.row(align=True)
						if settings.driver_marker_filter == 'ALL':
							option.active = False
							option.enabled = False
						option.prop(settings, 'driver_marker_string', text='')
						col.separator()
						
						# Time settings
						row2 = col.row(align=True)
						row2.prop(settings, 'driver_marker_relative', expand=True)
						row3 = col.row(align=True)
						row3.prop(settings, 'driver_marker_seconds', expand=True)
						options = col.row(align=True)
						if not (relative and seconds):
							options.active = False
							options.enabled = False
							duration = 1
						options.prop(settings, 'driver_marker_clamp', expand=True)
						
						direction = 'markerPrev' if settings.driver_select == 'MARKER-PREV' else 'markerNext'
						string = settings.driver_marker_string if settings.driver_marker_filter == 'FILTER' else ''
						
						if len(settings.driver_marker_string) == 0:
							error = 'missing filter string'
						else:
							# Short version for basic usage (interpolation added below)
							driver = f"{direction}('{string}'"
					
					# Marker Range
					elif settings.driver_select == 'MARKER-RANGE':
						range = True
						# Marker selection
						col.prop_search(settings, "driver_marker_name", context.scene, "timeline_markers", text="")
						col.prop_search(settings, "driver_marker_end", context.scene, "timeline_markers", text="")
						col.separator()
						
						# Time settings
						row1 = col.row()
						row1.prop(settings, 'driver_marker_clamp', expand=True)
						
						if settings.driver_marker_name == '' or settings.driver_marker_end == '':
							error = 'missing marker name'
						elif settings.driver_marker_name == settings.driver_marker_end:
							error = 'duplicate marker name'
						else:
							# Short version for basic usage (interpolation added below)
							driver = f"markerRange('{settings.driver_marker_name}', '{settings.driver_marker_end}'"
					
					# Menu Error
					else:
						error = 'invalid menu selection'
					
					# Value range UI
					rowA = col.row(align=True)
					if not range and not (relative and seconds and clamp):
						rowA.active = False
						rowA.enabled = False
					if not range:
						rowA.prop(settings, 'driver_marker_duration', text='')
					rowA.prop(settings, 'driver_value_a', text="")
					rowA.prop(settings, 'driver_value_b', text="")
					
					# Interpolation UI
					rowB = col.row(align=True)
					if not (((relative and seconds) or range) and clamp):
						rowB.active = False
						rowB.enabled = False
					rowB.prop(settings, 'driver_ease_type', text="")
					rowB.prop(settings, 'driver_ease_direction', text="")
					
					# Relative and seconds
					if (relative or seconds) and not range:
						driver += f", {relative}"
						if seconds:
							driver += f", {seconds}"
					
					# Clamp, range, and interpolation
					if ((relative and seconds) or range) and clamp:
						driver += f", {clamp}"
						if not range:
							driver += f", {duration}"
						
						# Get interpolation type
						easeType = settings.driver_ease_type
						linear = True if easeType == "linear" else False
						
						# We have to provide a range if the values are custom, regardless of interpolation type
						# But if we don't need interpolation, just the range alone is fine
						if valueA != 0 or valueB != 1 or not linear:
							driver += f", {valueA}, {valueB}"
							if not linear:
								driver += f", '{easeType}', '{settings.driver_ease_direction}'"
					# Support marker range remapping of start/end values when unclamped
					elif range and (valueA != 0 or valueB != 1):
						driver += f", {clamp}, {valueA}, {valueB}"
					
					# Complete driver with parenthetical closing
					driver += ")"
					
				else:
					error = 'no scene markers'
			
			# Random
			elif settings.driver_select == 'RANDOM':
				col.prop(settings, 'driver_random_min')
				col.prop(settings, 'driver_random_max')
				col.prop(settings, 'driver_random_seed')
				
				driver = f"random({settings.driver_random_min}, {settings.driver_random_max}, {settings.driver_random_seed})"
			
			# Wiggle
			elif settings.driver_select == 'WIGGLE':
				col.prop(settings, 'driver_wiggle_frequency')
				col.prop(settings, 'driver_wiggle_amplitude')
				col.prop(settings, 'driver_wiggle_octaves')
				col.prop(settings, 'driver_wiggle_seed')
				
				driver = f"wiggle({settings.driver_wiggle_frequency}, {settings.driver_wiggle_amplitude}, {settings.driver_wiggle_octaves}, {settings.driver_wiggle_seed})"
			
			# Copy to clipboard button
			layout.separator()
			button = layout.row()
			text = '#' + driver
			icon = 'COPYDOWN' # COPYDOWN PASTEDOWN
			if len(error) > 0:
				text = error
				icon = 'ERROR' # ERROR CANCEL
				button.active = False
				button.enabled = False
			ops = button.operator(CopyDriverToClipboard.bl_idname, text=text, icon=icon)
			ops.string = text
		
		except Exception as exc:
			print(str(exc) + " | Error in Production Kit Driver Functions panel")



class PRODUCTIONKIT_PT_driverFunctions_find_replace(bpy.types.Panel):
	bl_label = "Find & Replace"
	bl_idname = "PRODUCTIONKIT_PT_driverFunctions_find_replace"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_parent_id = "PRODUCTIONKIT_PT_driverFunctions"
	bl_options = {'DEFAULT_CLOSED'}
	
	@classmethod
	def poll(cls, context):
		return context.scene.timeline_markers and 'MARKER-' in context.scene.production_kit_settings.driver_select
	
	def draw_header(self, context):
		try:
			layout = self.layout
		except Exception as exc:
			print(str(exc) + " | Error in Production Kit Driver Functions Find & Replace subpanel header")
	
	def draw(self, context):
		try:
			settings = context.scene.production_kit_settings
			col = self.layout.column(align=True)
			row = col.row(align=True)
			row.prop(settings, 'driver_marker_find', text='')
			row.prop(settings, 'driver_marker_replace', text='')
			row = col.row(align=True)
			row.operator(WM_OT_find_replace_marker_expression.bl_idname, icon='ZOOM_ALL') # ZOOM_ALL VIEWZOOM SORTBYEXT
		except Exception as exc:
			print(str(exc) + " | Error in Production Kit Driver Functions Find & Replace subpanel")





###########################################################################
# Addon registration functions

# Register custom functions in Blender's driver namespace
def production_kit_driver_functions():
	dns = bpy.app.driver_namespace
	dns["curveAtTime"] = curve_at_time
	dns["ease"] = ease
	dns["hash"] = hash
	dns["hsv"] = hsv
	dns["lerp"] = lerp
#	dns["mix"] = lerp
	dns["markerValue"] = marker_value
	dns["markerRange"] = marker_range
	dns["markerPrev"] = marker_prev
	dns["markerNext"] = marker_next
	dns["random"] = random
	dns["wiggle"] = wiggle

# Persistent handler to register custom functions after file load
@persistent
def load_handler(dummy):
	production_kit_driver_functions()

classes = (
	CopyDriverToClipboard,
	WM_OT_find_replace_marker_expression,
	PRODUCTIONKIT_PT_driverFunctions,
	PRODUCTIONKIT_PT_driverFunctions_find_replace)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	production_kit_driver_functions()
#	bpy.app.handlers.load_pre.append(load_handler)
	bpy.app.handlers.load_post.append(load_handler)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
#	if load_handler in bpy.app.handlers.load_pre:
#		bpy.app.handlers.load_pre.remove(load_handler)
	if load_handler in bpy.app.handlers.load_post:
		bpy.app.handlers.load_post.remove(load_handler)

if __name__ == "__main__":
	register()
	