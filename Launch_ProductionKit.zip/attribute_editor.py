import bpy
from bpy.types import Panel, Operator, PropertyGroup, UIList
from bpy.props import (
	EnumProperty,
	PointerProperty,
	StringProperty,
	FloatProperty,
	IntProperty,
	BoolProperty,
	FloatVectorProperty,
)



# Helper functions

def get_current_domain():
	"""Return the domain corresponding to the current selection mode."""
	obj = bpy.context.active_object
	if obj is None or obj.type != 'MESH':
		return None
	
	# Determine mode from tool settings
	# Vertex select mode => domain = POINT
	# Edge select mode => domain = EDGE
	# Face select mode => domain = FACE
	modes = bpy.context.tool_settings.mesh_select_mode
	# modes is a tuple like (vertex, edge, face)
	if modes[0]:
		return 'POINT'
	elif modes[1]:
		return 'EDGE'
	elif modes[2]:
		return 'FACE'
	return None



def supported_data_type(data_type: str):
	"""Check if data type is one of the supported attribute data types."""
	# Common data types in attributes:
	# FLOAT, INT, FLOAT_VECTOR, FLOAT_COLOR, BYTE_COLOR, ...
	# We'll consider INT as representing an integer type, and handle boolean as int too.
	# For floats & vectors & colors, we handle those. Skip matrices or strings.
	allowed = {'FLOAT', 'INT', 'FLOAT_VECTOR', 'FLOAT_COLOR'}
	return data_type in allowed



# Property group to hold the selected attribute data
class AttributeEditProperties(PropertyGroup):
	attribute_name: StringProperty(
		name="Attribute",
		description="Name of the selected attribute"
	)
	attribute_domain: StringProperty(
		name="Domain",
		description="Domain of the selected attribute"
	)
	attribute_data_type: StringProperty(
		name="Data Type",
		description="Data type of the selected attribute"
	)
	
	# We'll provide a variety of properties and show/hide them depending on data_type
	float_val: FloatProperty(
		name="Value",
		default=0.0
	)
	int_val: IntProperty(
		name="Value",
		default=0
	)
	bool_val: BoolProperty(
		name="Value",
		default=False
	)
	vector_val: FloatVectorProperty(
		name="Value",
		size=3,
		default=(0.0, 0.0, 0.0)
	)
	color_val: FloatVectorProperty(
		name="Value",
		size=4,
		default=(1.0, 1.0, 1.0, 1.0),
		subtype='COLOR'
	)
	
	def update_value_from_attribute(self, attr):
		"""Update the stored properties with a representative value from the attribute if needed."""
		# This could pull from a selected element, but here we just set defaults.
		# For demonstration, we do nothing. In a real scenario, you might average
		# or pick the first selected element's attribute value as initial.
		pass



class ATTRIBUTE_UL_list(UIList):
	"""UIList to show the attributes."""
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
		# item is an attribute object
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			layout.label(text=item.name)
		elif self.layout_type == 'GRID':
			layout.alignment = 'CENTER'
			layout.label(text="")  # not used in grid mode



class ATTRIBUTE_OT_set(Operator):
	"""Set the attribute for selected elements."""
	bl_idname = "object.set_attribute_value"
	bl_label = "Set Attribute Value"
	bl_options = {'REGISTER', 'UNDO'}
	
	def execute(self, context):
		props = context.scene.attribute_edit_properties
		obj = context.active_object
		if obj is None or obj.type != 'MESH':
			self.report({'ERROR'}, "No mesh object selected.")
			return {'CANCELLED'}
		
		domain = props.attribute_domain
		attr_name = props.attribute_name
		data_type = props.attribute_data_type
		if not attr_name:
			self.report({'ERROR'}, "No attribute selected.")
			return {'CANCELLED'}
		
		mesh = obj.data
		attr = mesh.attributes.get(attr_name)
		if attr is None:
			self.report({'ERROR'}, "Attribute not found.")
			return {'CANCELLED'}
		
		# Get selected elements depending on domain
		bpy.ops.object.mode_set(mode='EDIT')
		bm = None
		import bmesh
		bm = bmesh.from_edit_mesh(mesh)
		
		if domain == 'POINT':
			# Vertex domain
			indices = [v.index for v in bm.verts if v.select]
		elif domain == 'EDGE':
			# Edge domain
			indices = [e.index for e in bm.edges if e.select]
		elif domain == 'FACE':
			# Face domain
			indices = [f.index for f in bm.faces if f.select]
		else:
			indices = []
		
		# Determine new value to set
		if data_type == 'FLOAT':
			val = props.float_val
		elif data_type == 'INT':
			val = props.int_val
		elif data_type == 'FLOAT_VECTOR':
			val = props.vector_val
		elif data_type == 'FLOAT_COLOR':
			val = props.color_val
		else:
			# If boolean is handled as int:
			if data_type == 'BOOLEAN':
				val = 1 if props.bool_val else 0
			else:
				self.report({'ERROR'}, "Unsupported data type.")
				return {'CANCELLED'}
			
		# Assign value to all selected elements
		# attr.data is array-like, indexed by element index
		for i in indices:
			attr.data[i].value = val
		
		bmesh.update_edit_mesh(mesh, loop_triangles=False)
		self.report({'INFO'}, f"Set attribute '{attr_name}' for {len(indices)} elements.")
		return {'FINISHED'}



class ATTRIBUTE_PT_panel(Panel):
	"""Main panel in the 3D viewport for attribute editing."""
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Edit"
	bl_label = "Attribute Editor"
	bl_context = "mesh_edit"  # ensures it appears in edit mode for meshes
	
	def draw(self, context):
		layout = self.layout
		props = context.scene.attribute_edit_properties
		obj = context.active_object
		
		if obj is None or obj.type != 'MESH':
			layout.label(text="No mesh object selected.")
			return
		
		domain = get_current_domain()
		if domain is None:
			layout.label(text="Select Vert/Edge/Face mode.")
			return
		
		mesh = obj.data
		# Filter attributes by domain and supported data type
		attrs = [a for a in mesh.attributes if a.domain == domain and supported_data_type(a.data_type)]
		
		if not attrs:
			layout.label(text="No compatible attributes found.")
			return
		
		# We store active attribute index in scene for simplicity
		scene = context.scene
		if "attribute_list_index" not in scene:
			scene["attribute_list_index"] = 0
		
		layout.template_list("ATTRIBUTE_UL_list", "", mesh, "attributes", scene, "attribute_list_index", rows=5, type='SCROLL')
		
		# Determine selected attribute from list index
		idx = scene["attribute_list_index"]
		filtered_attrs = attrs
		# We must find the actual attribute in filtered_attrs that matches the displayed list.
		# The template_list shows ALL attributes in mesh.attributes, so let's match them by name:
		displayed_attrs = [a for a in mesh.attributes if a.domain == domain and supported_data_type(a.data_type)]
		if 0 <= idx < len(displayed_attrs):
			selected_attr = displayed_attrs[idx]
		else:
			selected_attr = None
		
		if selected_attr:
			props.attribute_name = selected_attr.name
			props.attribute_domain = selected_attr.domain
			props.attribute_data_type = selected_attr.data_type
			
			box = layout.box()
			box.label(text=f"Selected: {selected_attr.name} ({selected_attr.data_type})")
			
			# Show the appropriate property depending on data type
			dt = selected_attr.data_type
			if dt == 'FLOAT':
				box.prop(props, "float_val")
			elif dt == 'INT':
				box.prop(props, "int_val")
			elif dt == 'FLOAT_VECTOR':
				box.prop(props, "vector_val")
			elif dt == 'FLOAT_COLOR':
				box.prop(props, "color_val")
			else:
				# If you had a boolean scenario (assuming INT for bool):
				# box.prop(props, "bool_val")
				pass
			
			box.operator("object.set_attribute_value", text="Set Attribute Value")



def register():
	bpy.utils.register_class(AttributeEditProperties)
	bpy.types.Scene.attribute_edit_properties = PointerProperty(type=AttributeEditProperties)
	bpy.utils.register_class(ATTRIBUTE_UL_list)
	bpy.utils.register_class(ATTRIBUTE_OT_set)
	bpy.utils.register_class(ATTRIBUTE_PT_panel)


def unregister():
	del bpy.types.Scene.attribute_edit_properties
	bpy.utils.unregister_class(ATTRIBUTE_PT_panel)
	bpy.utils.unregister_class(ATTRIBUTE_OT_set)
	bpy.utils.unregister_class(ATTRIBUTE_UL_list)
	bpy.utils.unregister_class(AttributeEditProperties)

if __name__ == "__main__":
	register()
